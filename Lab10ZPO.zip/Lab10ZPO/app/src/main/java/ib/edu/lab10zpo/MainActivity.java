package ib.edu.lab10zpo;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends Activity {
    SQLiteDatabase database;
    int[] columnIndices = new int[3];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        database = openOrCreateDatabase("STUDENCI", MODE_PRIVATE, null);
        // pierwszy parametr to nazwa bazy, drugi to tryb dostępu, a trzeci kursor (parametr
        // opcjonalny, tymczasowa struktura służąca do pobierania wyniku zapytania SQL).
//        Kursor umożliwia pobieranie rekordów sekwencyjnie, po jednym lub więcej naraz, a także
//        przemieszczanie się po wynikach zapytania. Tryb MODE_PRIVATE oznacza, że utworzona,
//                lokalna baza jest wykorzystywana tylko przez aplikację.
        String sqlDB = "CREATE TABLE IF NOT EXISTS STUDENCI (Id INTEGER, Imie VARCHAR, Nazwisko VARCHAR)";
        database.execSQL(sqlDB);
        String sqlCount = "SELECT count(*) FROM STUDENCI";
        Cursor cursor = database.rawQuery(sqlCount, null);
//        Drugi parametr określa zestaw argumentów zapytania. W zapytaniu używamy znaków
// ? w miejscach, gdzie mają pojawić się argumenty. Jeżeli zapytanie nie ma parametrów, to jako
//        drugi parametr przekazujemy wartość null.
        cursor.moveToFirst();
        int x = cursor.getInt(0);
        cursor.close();
//        (UWAGA: parametry są
//        indeksowane od 1!):
        if (x == 0) {
            String sqlStudent = "INSERT INTO STUDENCI VALUES (?,?,?)";
            SQLiteStatement statement =
                    database.compileStatement(sqlStudent);
            statement.bindLong(1, 1);
            statement.bindString(2, "Jan");
            statement.bindString(3, "Kowalski");
            statement.executeInsert();
            statement.bindLong(1, 2);
            statement.bindString(2, "Anna");
            statement.bindString(3, "Nowak");
            statement.executeInsert();
        }
    }

    public void showOnClick(View view) {
        ArrayList<String> wyniki = new ArrayList<>();
        Cursor c = database.rawQuery("SELECT Id, Imie, Nazwisko FROM STUDENCI", null);
        if (c.moveToFirst()) {
            columnIndices[0] = c.getColumnIndex("Id") + 1;
            columnIndices[1] = c.getColumnIndex("Imie") + 1;
            columnIndices[2] = c.getColumnIndex("Nazwisko") + 1;
            do {
                int id = c.getInt(c.getColumnIndex("Id"));
                String imie = c.getString(c.getColumnIndex("Imie"));
                String nazwisko =
                        c.getString(c.getColumnIndex("Nazwisko"));
                wyniki.add("Id: " + id + " , Imię: " + imie + ", Nazwisko: " + nazwisko);
            } while (c.moveToNext());
        }
        ListView listView = (ListView) findViewById(R.id.listView);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, wyniki);
        listView.setAdapter(adapter);
        c.close();
    }

    public void addOnClick(View view) {
        Intent intent = new Intent(this, Main2Activity.class);
        intent.putExtra("ID_COL", columnIndices[0]);
        intent.putExtra("SURNAME_COL", columnIndices[1]);
        intent.putExtra("NAME_COL", columnIndices[2]);
        this.startActivity(intent);
    }


    public void deleteOnClick(View view) {
        Intent intent = new Intent(this, Main3Activity.class);
        intent.putExtra("ID_COL", columnIndices[0]);
        intent.putExtra("SURNAME_COL", columnIndices[1]);
        intent.putExtra("NAME_COL", columnIndices[2]);
        this.startActivity(intent);
    }
}