package ib.edu.lab10zpo;

import android.app.Activity;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class Main3Activity extends Activity {
    SQLiteDatabase database;
    int[] columnIndices = new int[3];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        database = openOrCreateDatabase("STUDENCI", MODE_PRIVATE, null);
        String sqlDB = "CREATE TABLE IF NOT EXISTS STUDENCI (Id INTEGER, Imie VARCHAR, Nazwisko VARCHAR)";
        database.execSQL(sqlDB);
        columnIndices[0] = getIntent().getIntExtra("ID_COL",0);
        columnIndices[1] = getIntent().getIntExtra("SURNAME_COL",0);
        columnIndices[2] = getIntent().getIntExtra("NAME_COL",0);
        Log.d("loadint", String.valueOf(columnIndices[1]));
    }
    public void deleteRecordOnClick(View view) { // USUWANIE Z bazy
        EditText et1 = (EditText) findViewById(R.id.idEditText);
        int id = Integer.valueOf(et1.getText().toString());
         database.delete("STUDENCI", "Id" + "=" + id, null) ;
    }
}
